import Foundation
public protocol ViewState {}
public protocol UserIntent {}
