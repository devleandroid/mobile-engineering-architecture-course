import org.junit.Assert.assertEquals
import org.junit.Test

class CalculatorTest {
    @Test
    fun addition_isCorrect() {
        val expected = 4
        val actual = 2 + 2
        assertEquals(expected, actual)
    }
}
