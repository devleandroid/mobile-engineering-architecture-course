import XCTest

final class CalculatorTests: XCTestCase {
    func testAddition() {
        let expected = 4
        let actual = 2 + 2
        XCTAssertEqual(expected, actual)
    }
}
