rootProject.name = "MultiModule"
include(":app", ":core:network", ":feature:home")
